//
//  podtest1.h
//  podtest1
//
//  Created by Imai Hiroshi on 5/11/23.
//

#import <Foundation/Foundation.h>

//! Project version number for podtest1.
FOUNDATION_EXPORT double podtest1VersionNumber;

//! Project version string for podtest1.
FOUNDATION_EXPORT const unsigned char podtest1VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <podtest1/PublicHeader.h>


